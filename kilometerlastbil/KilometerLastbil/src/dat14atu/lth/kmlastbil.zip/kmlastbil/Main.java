package dat14atu.lth.kmlastbil;

import java.util.Locale;

import dat14atu.lth.kmlastbil.clevergirl.OptimizerCleverGirl;

public class Main {
	
	// settings
	final static boolean VERBOSE = false;
	final static long STARTING_SEED = 0;
	final static double SCORE_IS_TIE = 0.0000001;
	final static int PRINT_INTERVAL = 100;
	final static int ROUNDS = 1000;
	
	// model
	final static int FACTORY_COUNT = 3;
	final static int STORE_COUNT = 8;
	
	private static IOptimizer optimizers[];
	private static double[][] scores;
	private static long[][] timings;
	
	public static void main(String[] args) {
		
		System.out.println("V�lkommen till Bobs KilometerLastbils-r�knare.\n");
		
		optimizers = new IOptimizer[] {
			new OptimizerShortestDistance(),
			new OptimizerMostLastbils(),
			new OptimizerEvenDistribution(),
			new OptimizerCleverGirl(new OptimizerShortestDistance(), false), 	// slow
			//new OptimizerCleverGirl(new OptimizerMostLastbils(), false),		// slow
			//new OptimizerCleverGirl(new OptimizerEvenDistribution(), false),	// slow
			new OptimizerCleverGirl(new OptimizerShortestDistance(), true),		// very slow
			new OptimizerCleverGirl(new OptimizerMostLastbils(), true),			// very slow
			//new OptimizerCleverGirl(new OptimizerEvenDistribution(), true)		// very slow
		};
		
		scores = new double[optimizers.length][ROUNDS];
		timings = new long[optimizers.length][ROUNDS];
		
		System.out.println("Running " + ROUNDS + " models starting at seed " + STARTING_SEED + " with " + FACTORY_COUNT + " factories and " + STORE_COUNT + " stores.");
		
		for(int round = 0; round < ROUNDS; round++) {
			int totalImpact = 0;
			int impact[] = new int[optimizers.length];
			if(VERBOSE) {
				System.out.println();
			}
			
			int optimizerIndex = 0;
			for(IOptimizer optimizer : optimizers) {
				Model model = new Model(STARTING_SEED + round, FACTORY_COUNT, STORE_COUNT);
				
				long startingTime = System.nanoTime();
				try {
					optimizer.run(model, VERBOSE);
				} catch (Exception e) {
					e.printStackTrace();
				}
				timings[optimizerIndex][round] = System.nanoTime() - startingTime;
				
				
				boolean verify = model.verify(VERBOSE);
				if(VERBOSE || !verify) {
					System.out.println(optimizer.getName() + " running on model with seed " + STARTING_SEED + " " + 
							(verify ? "PASSED!" : "FAILED!"));
				}
				if(!verify) {
					model.verify(true);
				}
				impact[optimizerIndex] = verify ? model.getKilometerLastbils() : 0;
				totalImpact += impact[optimizerIndex];
				if(VERBOSE) {
					System.out.println("Final environmental impact was " + impact[optimizerIndex]);
				}
				optimizerIndex++;
			}
			
			for(int optimizer = 0; optimizer < optimizers.length; optimizer++) {
				scores[optimizer][round] = impact[optimizer] == 0 ? 0 : 1.0 - impact[optimizer] / (1.0 * totalImpact);
			}
			
			// NOTHING BUT PRINTING AND SCORING BELOW
			if((round + 1) % PRINT_INTERVAL == 0 || round >= ROUNDS - 1) {

				System.out.println();
				
				// make sexy score board, lising optimizer placing totals
				int placings[][] = new int[optimizers.length][optimizers.length]; // [optimizer][# of placing #X]
				for(int scoreRound = 0; scoreRound <= round; scoreRound++) {
					
					// get score for this round
					double scoreboard[][] = new double[optimizers.length][2]; // [id][optimizer, score]
					for(int optimizer = 0; optimizer < optimizers.length; optimizer++) {
						scoreboard[optimizer] = new double[] { optimizer, scores[optimizer][scoreRound] };
					}
					
					// sort descending
					for(int j = 0; j < optimizers.length - 1; j++) {
						for(int k = j; k < optimizers.length; k++) {
							if(scoreboard[j][1] < scoreboard[k][1]) {
								double temp[] = scoreboard[k];
								scoreboard[k] = scoreboard[j];
								scoreboard[j] = temp;
							}
						}
					}
					
					// save placings
					for(int placing = 0; placing < optimizers.length; placing++) {
						if(placing > 0 && SCORE_IS_TIE > Math.abs(scoreboard[placing][1] - scoreboard[placing - 1][1])) {
							placings[(int) scoreboard[placing][0]][placing - 1] += 1;
						}
						else {
							placings[(int) scoreboard[placing][0]][placing] += 1;
						}
					}
				}
				
				// scoring and prints down below
				
				// sexy formatting
				String tableFormat = "%-60s" + new String(new char[optimizers.length]).replace("\0", "%10s") + "\n";
				
				// table header for sexy score board
				Object[] row = new String[optimizers.length + 1];
				row[0] = "";
				for(int col = 1; col < optimizers.length + 1; col++) {
					row[col] = "#" + col;
				}
				
				// print sexy header
				System.out.format(tableFormat, row);
				
				// # of placings at 1st, 2nd etc in sexy score board
				for(int optimizer = 0; optimizer < optimizers.length; optimizer++) {
					row[0] = optimizers[optimizer].getName();
					for(int placing = 0; placing < optimizers.length; placing++) {
						row[placing + 1] = "" + placings[optimizer][placing];
					}
					
					// print sexy content
					System.out.format(tableFormat, row);
				}
				if(round >= ROUNDS - 1) {
					// best and average
					double best[] = new double[optimizers.length];
					double tally[] = new double[optimizers.length];
					for(int optimizer = 0; optimizer < optimizers.length; optimizer++) {
						tally[optimizer] = 0;
						for(int scoreRound = 0; scoreRound < ROUNDS; scoreRound++) {
							
							// add up for total
							tally[optimizer] += scores[optimizer][scoreRound];
							
							// find best
							if(scores[optimizer][scoreRound] > best[optimizer]) {
								best[optimizer] = scores[optimizer][scoreRound];
							}
						}
						
						// average out total
						tally[optimizer] /= 1.0 * ROUNDS;
					}
					
					// print avg
					System.out.println();
					for(int i = 0; i < tally.length; i++) {
						System.out.println(optimizers[i].getName() + " got an average score of " + tally[i]);
					}
					
					// print best
					System.out.println();
					for(int i = 0; i < best.length; i++) {
						System.out.println(optimizers[i].getName() + " got a personal best of " + best[i]);
					}
					
					// print average run-time
					System.out.println();
					for(int optimizer = 0; optimizer < optimizers.length; optimizer++) {
						long total = 0;
						for(int scoreRound = 0; scoreRound < ROUNDS; scoreRound++) {
							total += timings[optimizer][scoreRound];
						}
						double average = (1.0 * total) / (1.0 * ROUNDS);
						average /= 1000000; // ns -> ms
						System.out.println(optimizers[optimizer].getName() + " got an average execution time of " + String.format(Locale.US, "%.3f", average) + " milliseconds.");
					}
				}
			}
		}
		
	}
}
