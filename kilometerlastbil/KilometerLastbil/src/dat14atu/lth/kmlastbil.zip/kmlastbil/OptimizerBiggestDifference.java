package dat14atu.lth.kmlastbil;

public class OptimizerBiggestDifference extends IOptimizer {

	public OptimizerBiggestDifference() {
		super("Biggest Difference First Optimizer");
	}
	
	@Override
	public void run(Model model, boolean verbose) throws Exception {
		
		// collect
		for(int factory = 0; factory < model.getFactories(); factory++) {
			
			// listing of KilometerLastbils for each factory-store supply based on whichever is smaller of produce and demand
			int kmls[] = new int[model.getStores()];
			for(int store = 0; store < model.getStores(); store++) {
				kmls[store] = Math.min(model.getFactoryOutput(factory), model.getStoreDemand(store)) * model.getDistance(factory, store);
			}
			// hmm
			
		}
		
		super.run(model, verbose);
	}
}
